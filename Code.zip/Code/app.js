var express = require('express');
var app = express();
var libEmail = require('emailjs/email');
var port = process.env.PORT || 8080;
var email_server = libEmail.server.connect({
    user: "sunnysinghdevcom@gmail.com",
    password: "S9223Santudev",
    host: "smtp.gmail.com",
    ssl: true,
    port: 465
});
app.use(express.json());
//app.use(bodyParser.urlencoded({ extended: false }));
app.get('/', function(req, res) {
    console.log("Index page called" + port);
    res.send("Index page");
});
app.get('/main', function(req, res) {
    res.send("hello");
});
app.post('/mail', function(req, res) {
    // First read existing users.
    //
    console.log(req.body);


    // send the message and get a callback with an error or details of the message that was sent
    email_server.send({
        text: "i hope this works",
        from: "Sunny Singh",
        to: "Sunny <sunnysingh.vpcoe@gmail.com>, SunnyEpicor <sunny.singh@gmail.com>",
        cc: "Sunny <sunny.iexceed@hotmail.com>",
        subject: "testing"
    }, function(err, message) {
        console.log(err || message);
    });
    res.send(req.body);
});
app.use("*", function(req, res) {
    console.log("/ others");
    console.log(req.body);
    res.send("Error 404");
});
var server = app.listen(port, function() {
    var host = server.address().address
    var port = server.address().port
    console.log("Example app listening at http://%s:%s", host, port)
}).on('error', function(eror) {
    console.log(error);
});
console.log("App started");